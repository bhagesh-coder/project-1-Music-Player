
   let currentSong= new Audio();
   let currFolder;
   let songs=[]

   function formatSongTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);

    const formattedSecs = String(secs).padStart(2, '0');
    return `${mins}:${formattedSecs}`;
}
 

async function getSongs(folder) {
    currFolder=folder;
    const a = await fetch(`http://127.0.0.1:5500/${folder}/`)
    let response = await a.text();
    console.log(response);
    let div = document.createElement("div");
    div.innerHTML = response;
    let as=div.getElementsByTagName("a");
    console.log(as)
    songs = [];

for (let i = 0; i < as.length; i++) {
    const element = as[i];

   if (
    element.href.includes(".mp3.preview") ||
    element.href.includes(".m4a.preview")
) {
    let filename = decodeURIComponent(
        element.href.split("/").pop()
    );

    filename = filename.replace(".preview", "");

    songs.push(filename);
}
    console.log(element.href);
}

console.log("Songs loaded:", songs);
     let songUL = document.querySelector(".songlist").getElementsByTagName("ul")[0];
     songUL.innerHTML=" ";
     for (const song of songs) {
       
        songUL.innerHTML= songUL.innerHTML+ `<li data-filename="${song}">
                             <img class="songImg invert" src="song.svg" alt="song">
                             <div class="info">
                                <div class="songname">${song.replaceAll("%20"," ").replaceAll("%"," ").replaceAll("_"," ")}</div>
                                <div>artist</div>
                            </div>
                            <div class="playnow">
                                <span>Play Now</span>
                                <img class="playimg invert" src="play.svg">
                            </div>

                        </li>`;  
    }
//attacj a event listener to each songs
Array.from(document.querySelector(".songlist").getElementsByTagName("li")).forEach(e => {
    e.addEventListener("click", () => {

        // Remove active class from all songs
        document.querySelectorAll(".songlist li").forEach(li => {
            li.classList.remove("active");
        });

        // Add active class to clicked song
        e.classList.add("active");

        playmusic(e.getAttribute("data-filename"));
    });
});

    return songs ;

} 

const playmusic = (track, pause = false, name = null) => {
   currentSong.src=`/${currFolder}/` +track

    if (!pause) {
        currentSong.play();
        play.src = "pause.svg";
    }

    // Correctly set song name
    const displayName = name || decodeURIComponent(track.split("/").pop()).split("_")[0];
    document.querySelector(".songinfo").innerHTML = displayName;
}

    async function displayAlbums() {
    
    const a = await fetch(`http://127.0.0.1:5500/songs/`)
    let response = await a.text();
    let div = document.createElement("div");
    div.innerHTML = response;
    let anchor=div.getElementsByTagName("a");
    let cardContainer=document.querySelector(".cardContainer")
    let array=Array.from(anchor)
    for (let index = 0; index < array.length; index++) {
        const e = array[index];

       if (e.href.includes("/songs/")) {
    let folder = e.href.split("/").filter(Boolean).pop();

    try {
        const a = await fetch(`http://127.0.0.1:5500/songs/${folder}/info.json`);
        const response = await a.json();

        console.log(response);

        cardContainer.innerHTML += `
        <div class="card" data-folder="${folder}">
            <div class="play">
                <svg width="40" height="40" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="60" cy="60" r="50" fill="green" />
                    <polygon points="50,40 80,60 50,80" fill="black" />
                </svg>
            </div>
            <img src="/songs/${folder}/cover.jpg">
            <h2>${response.title}</h2>
            <p>${response.description}</p>
        </div>`;
    } catch (err) {
        console.warn(`info.json missing or invalid for ${folder}`, err);
    }
}

    }
    
//load the playlist whenever card is clicked
Array.from(document.getElementsByClassName("card")).forEach(card => {
    card.addEventListener("click", async (item) => {

        // Remove active class from all cards
        document.querySelectorAll(".card").forEach(c => {
            c.classList.remove("active");
        });

        // Highlight clicked card
        card.classList.add("active");

        // Load songs
        songs = await getSongs(`songs/${item.currentTarget.dataset.folder}`);

        
    });
});
        
    }

async function main() {
 
    //get songs
    songs= await getSongs("songs/cs")
    
    if (songs.length > 0) {
    playmusic(songs[0], true);
} else {
    console.error("No songs found");
}

    //display all the albums on the page
    displayAlbums();
    
//attach an event listner to play each song
 play.addEventListener("click",()=>{
        if(currentSong.paused)
        {
            currentSong.play();
            play.src="pause.svg";
        }
        else{
            currentSong.pause();
            play.src="play.svg";
        }
    })

    //update song time
    currentSong.addEventListener("timeupdate", () => {
    if (!isNaN(currentSong.duration)) {
        document.querySelector(".songtime").innerHTML = 
            `${formatSongTime(currentSong.currentTime)}/${formatSongTime(currentSong.duration)}`;
        document.querySelector(".circle").style.left=(currentSong.currentTime/currentSong.duration)*100 +"%";    
    }
   })

   //update seekbar
    document.querySelector(".seekbar").addEventListener("click", e=>{
    let percent=(e.offsetX/e.target.getBoundingClientRect().width)*100;
    document.querySelector(".circle").style.left=percent +"%";
    currentSong.currentTime = ((currentSong.duration)*percent)/100
   })
   currentSong.addEventListener("ended", () => {
    document.querySelector(".circle").style.left = "0%";
    play.src = "play.svg";
});


//attach an event listner to play , next, previous
   previous.addEventListener("click", () => {
    let currentIndex = songs.findIndex(s => s.includes(currentSong.src.split("/").pop()));
    if (currentIndex > 0) {
        let newSong = songs[currentIndex - 1];
        clickedName = decodeURIComponent(newSong.split("/").pop()).split("_")[0];
        playmusic(newSong, false, clickedName);
    }
});


next.addEventListener("click", () => {
    let currentIndex = songs.findIndex(s => s.includes(currentSong.src.split("/").pop()));
    if (currentIndex < songs.length - 1) {
        let newSong = songs[currentIndex + 1];
        clickedName = decodeURIComponent(newSong.split("/").pop()).split("_")[0];
        playmusic(newSong, false, clickedName);
    }
});

//setting volume
document.querySelector(".range").getElementsByTagName("input")[0].addEventListener("change",(e)=>{
    currentSong.volume=parseInt(e.target.value)/100
})

let isMuted = false;
let volimg = document.querySelector(".volimg");
document.querySelector(".volimg").addEventListener("click",(e)=>{
     if (!isMuted) {
        currentSong.volume = 0;
        document.querySelector(".range input").value = 0;
        isMuted = true;
        volimg.src = "mute.svg"; // if you have a mute icon
    } else {
        currentSong.volume = 1;
        document.querySelector(".range input").value = 100;
        isMuted = false;
        volimg.src = "volume.svg"; // restore original
    }
})



}
main()
